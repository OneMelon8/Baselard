package JProjects.BaseInfoBot.commands.moe.combat;

import JProjects.BaseInfoBot.database.moe.MoePixie;

public class CombatSuit {

	public static void mount(MoePixie pix) {
		// do scaling etc
	};
}
