package JProjects.BaseInfoBot.commands.moe.hangar;

import org.json.simple.JSONObject;

import JProjects.BaseInfoBot.BaseInfoBot;
import JProjects.BaseInfoBot.database.files.HangarFileEditor;
import JProjects.BaseInfoBot.database.moe.MoeSuit;
import JProjects.BaseInfoBot.tools.GeneralTools;
import net.dv8tion.jda.core.entities.Message;
import net.dv8tion.jda.core.entities.MessageChannel;
import net.dv8tion.jda.core.entities.User;

public class HangarDisplay {

	public static void fire(User author, String command, String[] args, Message message, MessageChannel channel,
			BaseInfoBot bot) {
		try {
			JSONObject obj = HangarFileEditor.read();
			if (!obj.containsKey(author.getId())) {
				bot.sendMessage(author.getAsMention() + " you have no suits in the hangar!", channel);
				return;
			}
			MoeSuit suit = MoeSuit.fromString((String) obj.get(author.getId()));
			bot.sendMessage(suit.toEmbededMessage(false, null), channel);
		} catch (Exception ex) {
			GeneralTools.logError(ex);
			bot.sendMessage(author.getAsMention() + " I cannot get your suit information right now, try again later.",
					channel);
		}
	}
}
